Test environment for Mozmill test execution via the command line on Mac.

Usage
=====

The run script can be used in interactive or scripted mode. For the latter,
parameters have to be passed in.

Interactive:   . ./run
Scripted:      ./run mozmill -b /Applications/Firefox.app -t ~/mozmill-tests/firefox
