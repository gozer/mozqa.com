Test environment for Mozmill test execution via the command line on Linux.

Usage
=====

The run script can be used in interactive or scripted mode. For the latter,
parameters have to be passed in.

Interactive:   . ./run
Scripted:      ./run mozmill -b /usr/bin/firefox-bin -t ~/mozmill-tests/firefox
