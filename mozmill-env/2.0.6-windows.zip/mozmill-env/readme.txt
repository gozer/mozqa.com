Test environment for Mozmill test execution via the command line on Windows.

Usage
=====

The run script can be used in interactive or scripted mode. For the latter,
parameters have to be passed in.

The maximum number of allowed parameters in scripted mode is 9.

Interactive:   run.cmd
Scripted:      run.cmd mozmill -b c:\(path to)\firefox.exe -t c:\mozmill-tests\firefox
