See http://mozbase.readthedocs.org


